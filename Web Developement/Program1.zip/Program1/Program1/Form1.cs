﻿// Grading ID: B1667
// Program 1
// Due Date: Sept. 27th, 2016
// Section: CIS199-75
// This program will return the total square feet, number of gallons, number of hours,
// price of paint, price of labor, and total cost based on the input in the square feet,
// number of coats, and price per gallon textboxes.


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Program1 : Form
    {
        public Program1()
        {
            InitializeComponent();
        }
        
        
        private void CalculateButton_Click(object sender, EventArgs e) // click to calculate based on the input in
            // square feet, number of coats, and price per gallon textboxes.
        
        {
            double squareFeet; // declares square feet as a double floating point number.
            int numberOfCoats; // declares number of coats as an integer.
            double pricePerGallon; // declares price per gallon as a double floating point number.
            double totalSquareFeet; // declares total square feet as a double floating point number.
            double numberOfGallons; // declares number of gallons as a double floating point number.
            double numberOfHours; // declares number of hours as a double floating point number.
            double priceOfPaint;// declares price of paint as a double floating point number.
            double priceOfLabor;// declares price of labor as a double floating point number.
            double totalCostPaintJob;// declares total cost of paint job as a double floating point number.
            const double SQUARE_FEET = 275; // declares constant for square feet.
            const double HOURS_LABOR = 8; // declares constant for hours of labor.
            const double PRICE_PER_HOUR = 12.50; // declares constant for price per hour.
            

            squareFeet = double.Parse(SquareFeetTextBox.Text); // obtain the users input for square feet.
            numberOfCoats = int.Parse(CoatsTextBox.Text); // obtain the users input for number of coats.
            pricePerGallon = double.Parse(PricePerGallonTextBox.Text); // obtain the users input for price per gallon.


            totalSquareFeet = squareFeet * numberOfCoats; // calculates total square feet.
            numberOfGallons = Math.Ceiling(totalSquareFeet / SQUARE_FEET); // calculates number of gallons.
            numberOfHours =  (totalSquareFeet/SQUARE_FEET) * HOURS_LABOR; // calculates number of hours.
            priceOfPaint = numberOfGallons * pricePerGallon; // calculates price of paint.
            priceOfLabor = numberOfHours * PRICE_PER_HOUR; // calculates price of labor.
            totalCostPaintJob = priceOfPaint + priceOfLabor; // calculates total cost of paint job.


            TotalSquareFeetReturn.Text = totalSquareFeet.ToString(); // Displays total sqaure feet in the label.
            GallonReturn.Text = numberOfGallons.ToString(); // Displays number of gallons in the label.
            HourReturn.Text = numberOfHours.ToString("n1"); // Displays number of hours in the label to one decimal.
            PricePaintReturn.Text = priceOfPaint.ToString("c"); // Displays price of paint in the label with currency format.
            PriceLaborReturn.Text = priceOfLabor.ToString("c"); // Displays price of labor in the label with currency format.
            TotalCostPaintJobReturn.Text = totalCostPaintJob.ToString("c"); // Displays total cost of paint job in the label with currency format.


        }
    }
}
