﻿namespace Program1
{
    partial class Program1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SquareFeetTextBox = new System.Windows.Forms.TextBox();
            this.CoatsTextBox = new System.Windows.Forms.TextBox();
            this.PricePerGallonTextBox = new System.Windows.Forms.TextBox();
            this.SquareFeetLabel = new System.Windows.Forms.Label();
            this.CoatsLabel = new System.Windows.Forms.Label();
            this.PricePerGallonLabel = new System.Windows.Forms.Label();
            this.TotalSquareFeetReturn = new System.Windows.Forms.Label();
            this.GallonReturn = new System.Windows.Forms.Label();
            this.HourReturn = new System.Windows.Forms.Label();
            this.PricePaintReturn = new System.Windows.Forms.Label();
            this.TotalSquareFeetLabel = new System.Windows.Forms.Label();
            this.NumberOfGallonsLabel = new System.Windows.Forms.Label();
            this.NumberOfHoursLabel = new System.Windows.Forms.Label();
            this.PriceOfPaintLabel = new System.Windows.Forms.Label();
            this.PriceLaborReturn = new System.Windows.Forms.Label();
            this.PriceOfLaborLabel = new System.Windows.Forms.Label();
            this.TotalCostPaintJobReturn = new System.Windows.Forms.Label();
            this.TotalCostLabel = new System.Windows.Forms.Label();
            this.CalculateButton = new System.Windows.Forms.Button();
            this.paintJobLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // SquareFeetTextBox
            // 
            this.SquareFeetTextBox.Location = new System.Drawing.Point(99, 73);
            this.SquareFeetTextBox.Name = "SquareFeetTextBox";
            this.SquareFeetTextBox.Size = new System.Drawing.Size(100, 20);
            this.SquareFeetTextBox.TabIndex = 0;
            // 
            // CoatsTextBox
            // 
            this.CoatsTextBox.Location = new System.Drawing.Point(99, 109);
            this.CoatsTextBox.Name = "CoatsTextBox";
            this.CoatsTextBox.Size = new System.Drawing.Size(100, 20);
            this.CoatsTextBox.TabIndex = 1;
            // 
            // PricePerGallonTextBox
            // 
            this.PricePerGallonTextBox.Location = new System.Drawing.Point(99, 149);
            this.PricePerGallonTextBox.Name = "PricePerGallonTextBox";
            this.PricePerGallonTextBox.Size = new System.Drawing.Size(100, 20);
            this.PricePerGallonTextBox.TabIndex = 2;
            // 
            // SquareFeetLabel
            // 
            this.SquareFeetLabel.AutoSize = true;
            this.SquareFeetLabel.Location = new System.Drawing.Point(28, 76);
            this.SquareFeetLabel.Name = "SquareFeetLabel";
            this.SquareFeetLabel.Size = new System.Drawing.Size(65, 13);
            this.SquareFeetLabel.TabIndex = 3;
            this.SquareFeetLabel.Text = "Square Feet";
            // 
            // CoatsLabel
            // 
            this.CoatsLabel.AutoSize = true;
            this.CoatsLabel.Location = new System.Drawing.Point(10, 112);
            this.CoatsLabel.Name = "CoatsLabel";
            this.CoatsLabel.Size = new System.Drawing.Size(86, 13);
            this.CoatsLabel.TabIndex = 4;
            this.CoatsLabel.Text = "Number of Coats";
            // 
            // PricePerGallonLabel
            // 
            this.PricePerGallonLabel.AutoSize = true;
            this.PricePerGallonLabel.Location = new System.Drawing.Point(10, 152);
            this.PricePerGallonLabel.Name = "PricePerGallonLabel";
            this.PricePerGallonLabel.Size = new System.Drawing.Size(83, 13);
            this.PricePerGallonLabel.TabIndex = 5;
            this.PricePerGallonLabel.Text = "Price Per Gallon";
            // 
            // TotalSquareFeetReturn
            // 
            this.TotalSquareFeetReturn.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TotalSquareFeetReturn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalSquareFeetReturn.Location = new System.Drawing.Point(331, 35);
            this.TotalSquareFeetReturn.Name = "TotalSquareFeetReturn";
            this.TotalSquareFeetReturn.Size = new System.Drawing.Size(113, 21);
            this.TotalSquareFeetReturn.TabIndex = 6;
            // 
            // GallonReturn
            // 
            this.GallonReturn.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.GallonReturn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.GallonReturn.Location = new System.Drawing.Point(331, 66);
            this.GallonReturn.Name = "GallonReturn";
            this.GallonReturn.Size = new System.Drawing.Size(113, 23);
            this.GallonReturn.TabIndex = 7;
            // 
            // HourReturn
            // 
            this.HourReturn.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.HourReturn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.HourReturn.Location = new System.Drawing.Point(331, 102);
            this.HourReturn.Name = "HourReturn";
            this.HourReturn.Size = new System.Drawing.Size(113, 23);
            this.HourReturn.TabIndex = 8;
            // 
            // PricePaintReturn
            // 
            this.PricePaintReturn.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.PricePaintReturn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PricePaintReturn.Location = new System.Drawing.Point(331, 142);
            this.PricePaintReturn.Name = "PricePaintReturn";
            this.PricePaintReturn.Size = new System.Drawing.Size(113, 23);
            this.PricePaintReturn.TabIndex = 9;
            // 
            // TotalSquareFeetLabel
            // 
            this.TotalSquareFeetLabel.AutoSize = true;
            this.TotalSquareFeetLabel.Location = new System.Drawing.Point(234, 35);
            this.TotalSquareFeetLabel.Name = "TotalSquareFeetLabel";
            this.TotalSquareFeetLabel.Size = new System.Drawing.Size(92, 13);
            this.TotalSquareFeetLabel.TabIndex = 10;
            this.TotalSquareFeetLabel.Text = "Total Square Feet";
            // 
            // NumberOfGallonsLabel
            // 
            this.NumberOfGallonsLabel.AutoSize = true;
            this.NumberOfGallonsLabel.Location = new System.Drawing.Point(234, 66);
            this.NumberOfGallonsLabel.Name = "NumberOfGallonsLabel";
            this.NumberOfGallonsLabel.Size = new System.Drawing.Size(97, 13);
            this.NumberOfGallonsLabel.TabIndex = 11;
            this.NumberOfGallonsLabel.Text = "Number of Gallons ";
            // 
            // NumberOfHoursLabel
            // 
            this.NumberOfHoursLabel.AutoSize = true;
            this.NumberOfHoursLabel.Location = new System.Drawing.Point(239, 102);
            this.NumberOfHoursLabel.Name = "NumberOfHoursLabel";
            this.NumberOfHoursLabel.Size = new System.Drawing.Size(87, 13);
            this.NumberOfHoursLabel.TabIndex = 12;
            this.NumberOfHoursLabel.Text = "Number of Hours";
            // 
            // PriceOfPaintLabel
            // 
            this.PriceOfPaintLabel.AutoSize = true;
            this.PriceOfPaintLabel.Location = new System.Drawing.Point(255, 142);
            this.PriceOfPaintLabel.Name = "PriceOfPaintLabel";
            this.PriceOfPaintLabel.Size = new System.Drawing.Size(70, 13);
            this.PriceOfPaintLabel.TabIndex = 13;
            this.PriceOfPaintLabel.Text = "Price of Paint";
            // 
            // PriceLaborReturn
            // 
            this.PriceLaborReturn.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.PriceLaborReturn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PriceLaborReturn.Location = new System.Drawing.Point(331, 179);
            this.PriceLaborReturn.Name = "PriceLaborReturn";
            this.PriceLaborReturn.Size = new System.Drawing.Size(113, 23);
            this.PriceLaborReturn.TabIndex = 14;
            // 
            // PriceOfLaborLabel
            // 
            this.PriceOfLaborLabel.AutoSize = true;
            this.PriceOfLaborLabel.Location = new System.Drawing.Point(253, 179);
            this.PriceOfLaborLabel.Name = "PriceOfLaborLabel";
            this.PriceOfLaborLabel.Size = new System.Drawing.Size(73, 13);
            this.PriceOfLaborLabel.TabIndex = 15;
            this.PriceOfLaborLabel.Text = "Price of Labor";
            // 
            // TotalCostPaintJobReturn
            // 
            this.TotalCostPaintJobReturn.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TotalCostPaintJobReturn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalCostPaintJobReturn.Location = new System.Drawing.Point(331, 216);
            this.TotalCostPaintJobReturn.Name = "TotalCostPaintJobReturn";
            this.TotalCostPaintJobReturn.Size = new System.Drawing.Size(113, 23);
            this.TotalCostPaintJobReturn.TabIndex = 16;
            // 
            // TotalCostLabel
            // 
            this.TotalCostLabel.AutoSize = true;
            this.TotalCostLabel.Location = new System.Drawing.Point(270, 216);
            this.TotalCostLabel.Name = "TotalCostLabel";
            this.TotalCostLabel.Size = new System.Drawing.Size(55, 13);
            this.TotalCostLabel.TabIndex = 17;
            this.TotalCostLabel.Text = "Total Cost";
            // 
            // CalculateButton
            // 
            this.CalculateButton.Location = new System.Drawing.Point(110, 195);
            this.CalculateButton.Name = "CalculateButton";
            this.CalculateButton.Size = new System.Drawing.Size(75, 23);
            this.CalculateButton.TabIndex = 18;
            this.CalculateButton.Text = "Calculate";
            this.CalculateButton.UseVisualStyleBackColor = true;
            this.CalculateButton.Click += new System.EventHandler(this.CalculateButton_Click);
            // 
            // paintJobLabel
            // 
            this.paintJobLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paintJobLabel.Location = new System.Drawing.Point(57, 25);
            this.paintJobLabel.Name = "paintJobLabel";
            this.paintJobLabel.Size = new System.Drawing.Size(119, 23);
            this.paintJobLabel.TabIndex = 19;
            this.paintJobLabel.Text = "Paint Job";
            // 
            // Program1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(477, 273);
            this.Controls.Add(this.paintJobLabel);
            this.Controls.Add(this.CalculateButton);
            this.Controls.Add(this.TotalCostLabel);
            this.Controls.Add(this.TotalCostPaintJobReturn);
            this.Controls.Add(this.PriceOfLaborLabel);
            this.Controls.Add(this.PriceLaborReturn);
            this.Controls.Add(this.PriceOfPaintLabel);
            this.Controls.Add(this.NumberOfHoursLabel);
            this.Controls.Add(this.NumberOfGallonsLabel);
            this.Controls.Add(this.TotalSquareFeetLabel);
            this.Controls.Add(this.PricePaintReturn);
            this.Controls.Add(this.HourReturn);
            this.Controls.Add(this.GallonReturn);
            this.Controls.Add(this.TotalSquareFeetReturn);
            this.Controls.Add(this.PricePerGallonLabel);
            this.Controls.Add(this.CoatsLabel);
            this.Controls.Add(this.SquareFeetLabel);
            this.Controls.Add(this.PricePerGallonTextBox);
            this.Controls.Add(this.CoatsTextBox);
            this.Controls.Add(this.SquareFeetTextBox);
            this.Name = "Program1";
            this.Text = "Program 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox SquareFeetTextBox;
        private System.Windows.Forms.TextBox CoatsTextBox;
        private System.Windows.Forms.TextBox PricePerGallonTextBox;
        private System.Windows.Forms.Label SquareFeetLabel;
        private System.Windows.Forms.Label CoatsLabel;
        private System.Windows.Forms.Label PricePerGallonLabel;
        private System.Windows.Forms.Label TotalSquareFeetReturn;
        private System.Windows.Forms.Label GallonReturn;
        private System.Windows.Forms.Label HourReturn;
        private System.Windows.Forms.Label PricePaintReturn;
        private System.Windows.Forms.Label TotalSquareFeetLabel;
        private System.Windows.Forms.Label NumberOfGallonsLabel;
        private System.Windows.Forms.Label NumberOfHoursLabel;
        private System.Windows.Forms.Label PriceOfPaintLabel;
        private System.Windows.Forms.Label PriceLaborReturn;
        private System.Windows.Forms.Label PriceOfLaborLabel;
        private System.Windows.Forms.Label TotalCostPaintJobReturn;
        private System.Windows.Forms.Label TotalCostLabel;
        private System.Windows.Forms.Button CalculateButton;
        private System.Windows.Forms.Label paintJobLabel;
    }
}

