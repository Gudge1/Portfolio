﻿namespace Program_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleTxtBox = new System.Windows.Forms.TextBox();
            this.authorTxtBox = new System.Windows.Forms.TextBox();
            this.publisherTxtBox = new System.Windows.Forms.TextBox();
            this.copyrightYearTxtBox = new System.Windows.Forms.TextBox();
            this.callNumberTxtBox = new System.Windows.Forms.TextBox();
            this.titleLabel = new System.Windows.Forms.Label();
            this.authorLabel = new System.Windows.Forms.Label();
            this.publisherLabel = new System.Windows.Forms.Label();
            this.copyrightYearLabel = new System.Windows.Forms.Label();
            this.callNumberLabel = new System.Windows.Forms.Label();
            this.addBookButton = new System.Windows.Forms.Button();
            this.titlesListBox = new System.Windows.Forms.ListBox();
            this.detailsButton = new System.Windows.Forms.Button();
            this.checkOutButton = new System.Windows.Forms.Button();
            this.returnButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // titleTxtBox
            // 
            this.titleTxtBox.Location = new System.Drawing.Point(79, 31);
            this.titleTxtBox.Name = "titleTxtBox";
            this.titleTxtBox.Size = new System.Drawing.Size(100, 20);
            this.titleTxtBox.TabIndex = 0;
            // 
            // authorTxtBox
            // 
            this.authorTxtBox.Location = new System.Drawing.Point(79, 57);
            this.authorTxtBox.Name = "authorTxtBox";
            this.authorTxtBox.Size = new System.Drawing.Size(100, 20);
            this.authorTxtBox.TabIndex = 1;
            // 
            // publisherTxtBox
            // 
            this.publisherTxtBox.Location = new System.Drawing.Point(79, 83);
            this.publisherTxtBox.Name = "publisherTxtBox";
            this.publisherTxtBox.Size = new System.Drawing.Size(100, 20);
            this.publisherTxtBox.TabIndex = 2;
            // 
            // copyrightYearTxtBox
            // 
            this.copyrightYearTxtBox.Location = new System.Drawing.Point(79, 109);
            this.copyrightYearTxtBox.Name = "copyrightYearTxtBox";
            this.copyrightYearTxtBox.Size = new System.Drawing.Size(100, 20);
            this.copyrightYearTxtBox.TabIndex = 3;
            // 
            // callNumberTxtBox
            // 
            this.callNumberTxtBox.Location = new System.Drawing.Point(79, 135);
            this.callNumberTxtBox.Name = "callNumberTxtBox";
            this.callNumberTxtBox.Size = new System.Drawing.Size(100, 20);
            this.callNumberTxtBox.TabIndex = 4;
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(46, 34);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(27, 13);
            this.titleLabel.TabIndex = 5;
            this.titleLabel.Text = "Title";
            // 
            // authorLabel
            // 
            this.authorLabel.AutoSize = true;
            this.authorLabel.Location = new System.Drawing.Point(35, 64);
            this.authorLabel.Name = "authorLabel";
            this.authorLabel.Size = new System.Drawing.Size(38, 13);
            this.authorLabel.TabIndex = 6;
            this.authorLabel.Text = "Author";
            // 
            // publisherLabel
            // 
            this.publisherLabel.AutoSize = true;
            this.publisherLabel.Location = new System.Drawing.Point(23, 90);
            this.publisherLabel.Name = "publisherLabel";
            this.publisherLabel.Size = new System.Drawing.Size(50, 13);
            this.publisherLabel.TabIndex = 7;
            this.publisherLabel.Text = "Publisher";
            // 
            // copyrightYearLabel
            // 
            this.copyrightYearLabel.AutoSize = true;
            this.copyrightYearLabel.Location = new System.Drawing.Point(0, 112);
            this.copyrightYearLabel.Name = "copyrightYearLabel";
            this.copyrightYearLabel.Size = new System.Drawing.Size(76, 13);
            this.copyrightYearLabel.TabIndex = 8;
            this.copyrightYearLabel.Text = "Copyright Year";
            // 
            // callNumberLabel
            // 
            this.callNumberLabel.AutoSize = true;
            this.callNumberLabel.Location = new System.Drawing.Point(9, 138);
            this.callNumberLabel.Name = "callNumberLabel";
            this.callNumberLabel.Size = new System.Drawing.Size(64, 13);
            this.callNumberLabel.TabIndex = 9;
            this.callNumberLabel.Text = "Call Number";
            // 
            // addBookButton
            // 
            this.addBookButton.Location = new System.Drawing.Point(93, 173);
            this.addBookButton.Name = "addBookButton";
            this.addBookButton.Size = new System.Drawing.Size(75, 23);
            this.addBookButton.TabIndex = 10;
            this.addBookButton.Text = "Add Book";
            this.addBookButton.UseVisualStyleBackColor = true;
            this.addBookButton.Click += new System.EventHandler(this.addBookButton_Click);
            // 
            // titlesListBox
            // 
            this.titlesListBox.FormattingEnabled = true;
            this.titlesListBox.Location = new System.Drawing.Point(208, 31);
            this.titlesListBox.Name = "titlesListBox";
            this.titlesListBox.Size = new System.Drawing.Size(120, 95);
            this.titlesListBox.TabIndex = 11;
            // 
            // detailsButton
            // 
            this.detailsButton.Location = new System.Drawing.Point(233, 157);
            this.detailsButton.Name = "detailsButton";
            this.detailsButton.Size = new System.Drawing.Size(75, 23);
            this.detailsButton.TabIndex = 12;
            this.detailsButton.Text = "Details";
            this.detailsButton.UseVisualStyleBackColor = true;
            this.detailsButton.Click += new System.EventHandler(this.detailsButton_Click);
            // 
            // checkOutButton
            // 
            this.checkOutButton.Location = new System.Drawing.Point(233, 186);
            this.checkOutButton.Name = "checkOutButton";
            this.checkOutButton.Size = new System.Drawing.Size(75, 23);
            this.checkOutButton.TabIndex = 13;
            this.checkOutButton.Text = "Check Out";
            this.checkOutButton.UseVisualStyleBackColor = true;
            this.checkOutButton.Click += new System.EventHandler(this.checkOutButton_Click);
            // 
            // returnButton
            // 
            this.returnButton.Location = new System.Drawing.Point(233, 215);
            this.returnButton.Name = "returnButton";
            this.returnButton.Size = new System.Drawing.Size(75, 23);
            this.returnButton.TabIndex = 14;
            this.returnButton.Text = "Return";
            this.returnButton.UseVisualStyleBackColor = true;
            this.returnButton.Click += new System.EventHandler(this.returnButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(352, 273);
            this.Controls.Add(this.returnButton);
            this.Controls.Add(this.checkOutButton);
            this.Controls.Add(this.detailsButton);
            this.Controls.Add(this.titlesListBox);
            this.Controls.Add(this.addBookButton);
            this.Controls.Add(this.callNumberLabel);
            this.Controls.Add(this.copyrightYearLabel);
            this.Controls.Add(this.publisherLabel);
            this.Controls.Add(this.authorLabel);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.callNumberTxtBox);
            this.Controls.Add(this.copyrightYearTxtBox);
            this.Controls.Add(this.publisherTxtBox);
            this.Controls.Add(this.authorTxtBox);
            this.Controls.Add(this.titleTxtBox);
            this.Name = "Form1";
            this.Text = "Program 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox titleTxtBox;
        private System.Windows.Forms.TextBox authorTxtBox;
        private System.Windows.Forms.TextBox publisherTxtBox;
        private System.Windows.Forms.TextBox copyrightYearTxtBox;
        private System.Windows.Forms.TextBox callNumberTxtBox;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label authorLabel;
        private System.Windows.Forms.Label publisherLabel;
        private System.Windows.Forms.Label copyrightYearLabel;
        private System.Windows.Forms.Label callNumberLabel;
        private System.Windows.Forms.Button addBookButton;
        private System.Windows.Forms.ListBox titlesListBox;
        private System.Windows.Forms.Button detailsButton;
        private System.Windows.Forms.Button checkOutButton;
        private System.Windows.Forms.Button returnButton;
    }
}

