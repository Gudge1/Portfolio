﻿// Program 4
// CIS199-75
// Due Date: December 6th
// Grading ID: B1667
// this is the LibraryBook class used to format the form

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    public class LibraryBook
    {
        private int _copyrightYear; // field
        private bool _checkedOut = false; // field

        // precondition: t = "", a = "", p = "", cy = 2016, cn = ""
        // postcondition: LibraryBook object initialized with the specified Title, Author, Publisher, CopyrightYear, and CallNumber 
        public LibraryBook(string t = "", string a = "", string p ="", int cy = 2016, string cn = "")
        {
            Title = t; // set the Title property
            Author = a; // set the Author property
            Publisher = p; // set the Publisher property
            CopyrightYear = cy; // set the CopyrightYear property
            CallNumber = cn; // set the CallNumber property
        }

        // precondition: none
        // postcondition: get and set property's value
        public string Title
        {
            get;
            set;
        }

        // precondition: none
        // postcondition: get and set property's value
        public string Author
        {
            get;
            set;
        }

        // precondition: none
        // postcondition: get and set property's value
        public string Publisher
        {
            get;
            set;
        }

        // precondition: value > -1
        // postcondition: return _copyrightYear; 
        public int CopyrightYear
        {
            get
            {
                return _copyrightYear;
            }

            set
            {
                if (value > -1)
                    _copyrightYear = value;
                else
                    _copyrightYear = 2016;
            }
        }

        // precondition: none
        // postcondition: get and set property's value
        public string CallNumber
        {
            get;
            set;
        }

        // precondition: none
        // postcondition: _checkedOut = true;
        public void CheckOut()
        {
            _checkedOut = true;
        }

        // precondition: none
        // postcondition: _checkedOut = false;
        public void ReturnToShelf()
        {
            _checkedOut = false;
        }

        // precondition: none
        // postcondition: return _checkedOut;
        public bool IsCheckedOut()
        {
            return _checkedOut;
        }

        // precondition: none
        // postcondition: a string is returned presenting format for details 
        public override string ToString()
        {
            string result;

            return result = "Title:" + Title + Environment.NewLine + "Author:" + Author + Environment.NewLine +
                "Publisher:" + Publisher + Environment.NewLine + "Copyright Year:" + CopyrightYear +
                Environment.NewLine + "Call Number:" + CallNumber + Environment.NewLine + "Checked Out:" + IsCheckedOut();            
        }

    }
}
