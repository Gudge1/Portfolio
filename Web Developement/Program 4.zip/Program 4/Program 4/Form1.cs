﻿// Program 4
// CIS199-75
// Due Date: December 6th
// Grading ID: B1667
// this program will return the details for the book data entered by the user and also allow you to check out/return the book by selecting book in list box

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_4
{
    public partial class Form1 : Form
    {
        // List to hold bookList objects
        List<LibraryBook> bookList = new List<LibraryBook>();

        public Form1()
        {
            InitializeComponent();
        }

        // precondition: if statement validation is not successful
        // postcondition: return body statement of else
        private void GetBookData(LibraryBook book)
        {
            int copyrightyear; // temporary variable to hold the price
                        
            if (string.IsNullOrWhiteSpace(titleTxtBox.Text) || string.IsNullOrWhiteSpace(authorTxtBox.Text)
                || string.IsNullOrWhiteSpace(publisherTxtBox.Text) || string.IsNullOrWhiteSpace(callNumberTxtBox.Text) 
                || !int.TryParse(copyrightYearTxtBox.Text, out copyrightyear))
            {
                MessageBox.Show("invalid input");
            }
            else 
            {
                book.Title = titleTxtBox.Text; // get title
                book.Author = authorTxtBox.Text; // get author
                book.Publisher = publisherTxtBox.Text; // get publisher
                book.CallNumber = callNumberTxtBox.Text; // get callnumber
                book.CopyrightYear = copyrightyear; // get copyrightyear
            }
        }

        // precondition: none
        // postcondition: add title to the list box
        private void addBookButton_Click(object sender, EventArgs e)
        {
            LibraryBook myBook = new LibraryBook(); // create LibraryBook object

            GetBookData(myBook); // get the book data

            bookList.Add(myBook); // add the LibraryBook object to the list

            titlesListBox.Items.Add(myBook.Title); // add entry to list box
        }

        // precondition: titlesListBox.SelectedIndex > -1
        // postcondtion: MessageBox.Show(bookList[index].ToString());
        private void detailsButton_Click(object sender, EventArgs e)
        {
            if(titlesListBox.SelectedIndex > -1)
            {
                int index = titlesListBox.SelectedIndex; // get index of selected item

                MessageBox.Show(bookList[index].ToString()); // display the book details
            }
            else
            {
                MessageBox.Show("Not Selected");
            }                                                
        }

        // precondition: titlesListBox.SelectedIndex > -1
        // postcondition: bookList[index].CheckOut();
        private void checkOutButton_Click(object sender, EventArgs e)
        {
            if(titlesListBox.SelectedIndex > -1)
            {
                int index = titlesListBox.SelectedIndex;

                bookList[index].CheckOut();

                MessageBox.Show("Book is checked out");
            }
            else
            {
                MessageBox.Show("Not Selected");
            }                                                
        }

        // precondition: titlesListBox.SelectedIndex > -1
        // postcondition: bookList[index].ReturnToShelf();
        private void returnButton_Click(object sender, EventArgs e)
        {
            if(titlesListBox.SelectedIndex > -1)
            {
                int index = titlesListBox.SelectedIndex;

                bookList[index].ReturnToShelf();

                MessageBox.Show("Book is returned");
            }
            else
            {
                MessageBox.Show("Not Selected");
            }
        }
    }
}
