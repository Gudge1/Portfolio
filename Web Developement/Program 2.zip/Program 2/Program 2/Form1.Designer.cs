﻿namespace Program_2
{
    partial class Program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.registrationDateAndTimeLabel = new System.Windows.Forms.Label();
            this.creditHoursCompletedTextBox = new System.Windows.Forms.TextBox();
            this.letterLastNameTextBox = new System.Windows.Forms.TextBox();
            this.creditHoursCompletedLabel = new System.Windows.Forms.Label();
            this.firstLetterOrLastNameLabel = new System.Windows.Forms.Label();
            this.registrationDateTimeGroupBox = new System.Windows.Forms.GroupBox();
            this.registrationTimeReturnLabel = new System.Windows.Forms.Label();
            this.registrationDateReturnLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.registrationDateTimeGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // registrationDateAndTimeLabel
            // 
            this.registrationDateAndTimeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.registrationDateAndTimeLabel.Location = new System.Drawing.Point(41, 9);
            this.registrationDateAndTimeLabel.Name = "registrationDateAndTimeLabel";
            this.registrationDateAndTimeLabel.Size = new System.Drawing.Size(204, 42);
            this.registrationDateAndTimeLabel.TabIndex = 0;
            this.registrationDateAndTimeLabel.Text = "Complete for Registration Date and Time";
            // 
            // creditHoursCompletedTextBox
            // 
            this.creditHoursCompletedTextBox.Location = new System.Drawing.Point(162, 63);
            this.creditHoursCompletedTextBox.Name = "creditHoursCompletedTextBox";
            this.creditHoursCompletedTextBox.Size = new System.Drawing.Size(100, 20);
            this.creditHoursCompletedTextBox.TabIndex = 1;
            // 
            // letterLastNameTextBox
            // 
            this.letterLastNameTextBox.Location = new System.Drawing.Point(162, 99);
            this.letterLastNameTextBox.Name = "letterLastNameTextBox";
            this.letterLastNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.letterLastNameTextBox.TabIndex = 2;
            // 
            // creditHoursCompletedLabel
            // 
            this.creditHoursCompletedLabel.AutoSize = true;
            this.creditHoursCompletedLabel.Location = new System.Drawing.Point(38, 66);
            this.creditHoursCompletedLabel.Name = "creditHoursCompletedLabel";
            this.creditHoursCompletedLabel.Size = new System.Drawing.Size(118, 13);
            this.creditHoursCompletedLabel.TabIndex = 3;
            this.creditHoursCompletedLabel.Text = "Credit Hours Completed";
            // 
            // firstLetterOrLastNameLabel
            // 
            this.firstLetterOrLastNameLabel.AutoSize = true;
            this.firstLetterOrLastNameLabel.Location = new System.Drawing.Point(-2, 102);
            this.firstLetterOrLastNameLabel.Name = "firstLetterOrLastNameLabel";
            this.firstLetterOrLastNameLabel.Size = new System.Drawing.Size(159, 13);
            this.firstLetterOrLastNameLabel.TabIndex = 4;
            this.firstLetterOrLastNameLabel.Text = "First Letter/Complete Last Name";
            // 
            // registrationDateTimeGroupBox
            // 
            this.registrationDateTimeGroupBox.Controls.Add(this.registrationTimeReturnLabel);
            this.registrationDateTimeGroupBox.Controls.Add(this.registrationDateReturnLabel);
            this.registrationDateTimeGroupBox.Location = new System.Drawing.Point(45, 139);
            this.registrationDateTimeGroupBox.Name = "registrationDateTimeGroupBox";
            this.registrationDateTimeGroupBox.Size = new System.Drawing.Size(200, 82);
            this.registrationDateTimeGroupBox.TabIndex = 5;
            this.registrationDateTimeGroupBox.TabStop = false;
            this.registrationDateTimeGroupBox.Text = "Registration Date/Time";
            // 
            // registrationTimeReturnLabel
            // 
            this.registrationTimeReturnLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.registrationTimeReturnLabel.Location = new System.Drawing.Point(50, 50);
            this.registrationTimeReturnLabel.Name = "registrationTimeReturnLabel";
            this.registrationTimeReturnLabel.Size = new System.Drawing.Size(100, 23);
            this.registrationTimeReturnLabel.TabIndex = 1;
            // 
            // registrationDateReturnLabel
            // 
            this.registrationDateReturnLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.registrationDateReturnLabel.Location = new System.Drawing.Point(50, 16);
            this.registrationDateReturnLabel.Name = "registrationDateReturnLabel";
            this.registrationDateReturnLabel.Size = new System.Drawing.Size(100, 23);
            this.registrationDateReturnLabel.TabIndex = 0;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(107, 227);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 6;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // Program2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.registrationDateTimeGroupBox);
            this.Controls.Add(this.firstLetterOrLastNameLabel);
            this.Controls.Add(this.creditHoursCompletedLabel);
            this.Controls.Add(this.letterLastNameTextBox);
            this.Controls.Add(this.creditHoursCompletedTextBox);
            this.Controls.Add(this.registrationDateAndTimeLabel);
            this.Name = "Program2";
            this.Text = "Program 2";
            this.registrationDateTimeGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label registrationDateAndTimeLabel;
        private System.Windows.Forms.TextBox creditHoursCompletedTextBox;
        private System.Windows.Forms.TextBox letterLastNameTextBox;
        private System.Windows.Forms.Label creditHoursCompletedLabel;
        private System.Windows.Forms.Label firstLetterOrLastNameLabel;
        private System.Windows.Forms.GroupBox registrationDateTimeGroupBox;
        private System.Windows.Forms.Label registrationTimeReturnLabel;
        private System.Windows.Forms.Label registrationDateReturnLabel;
        private System.Windows.Forms.Button calculateButton;
    }
}

