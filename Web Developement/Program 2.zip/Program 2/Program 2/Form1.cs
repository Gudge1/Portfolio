﻿// Grading ID B1667
// Program 2
// October 16th, 2016
// CIS199-75
// this program will display your registration date for classes based on your credit hours and beginning 
// letter of your last name.


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class Program2 : Form
    {
        public Program2()
        {
            InitializeComponent();
        }
        
        private void calculateButton_Click(object sender, EventArgs e) // click to return date and time for registration.
        {
            string lastName; // declare last name as string
            string firstLetterLastName; // declare first letter of last name as string                      
            double hoursCredit; // delcare credit hours as double
            const int SENIOR_HOURS = 90; // constant for senior creit hours
            const int JUNIOR_HOURS = 60; // constant for junior credit hours
            const int SOPHMORE_HOURS = 30; // constant for sophomore hours 

            if (letterLastNameTextBox.Text == "") // did the user enter something into text box

                MessageBox.Show("LAST NAME TEXTBOX BLANK"); // display if textbox is blank

            else

            if (double.TryParse(creditHoursCompletedTextBox.Text, out hoursCredit)) // is user textbox input floating point number
            {
                lastName = letterLastNameTextBox.Text; // declare letterLastNameTextBox as lastName string
                firstLetterLastName = lastName.Substring(0, 1); // take the first letter of the last name
                firstLetterLastName = firstLetterLastName.ToUpper(); // convert any input from letterLastNameTextBox into upper case 

                if (hoursCredit >= 0) // if credit hours are greater than or equal to 0
                {                                                       
                    if (hoursCredit >= JUNIOR_HOURS) // if credit hours are greater than or equal to 60
                    {
                        if (hoursCredit >= SENIOR_HOURS) // if credit hours are greater than or equal to 90

                            registrationDateReturnLabel.Text = "November 4"; // if senior hours

                        else

                            registrationDateReturnLabel.Text = "November 7"; // if junior hours


                        switch (firstLetterLastName) // based on first letter in textbox will display correct time in the specified label
                        {
                            case "A":
                            case "B":
                            case "C":
                            case "D":
                                registrationTimeReturnLabel.Text = "2:00 PM";
                                break;
                            case "E":
                            case "F":
                            case "G":
                            case "H":
                            case "I":
                                registrationTimeReturnLabel.Text = "4:00 PM";
                                break;
                            case "J":
                            case "L":
                            case "M":
                            case "N":
                            case "O":
                                registrationTimeReturnLabel.Text = "8:30 AM";
                                break;
                            case "P":
                            case "Q":
                            case "R":
                            case "S":
                                registrationTimeReturnLabel.Text = "10:00 AM";
                                break;
                            case "T":
                            case "U":
                            case "V":
                            case "W":
                            case "X":
                            case "Y":
                            case "Z":
                                registrationTimeReturnLabel.Text = "11:30 PM";
                                break;

                        }
                    }

                    else // if not junior or senior 
                    {
                        if (hoursCredit >= SOPHMORE_HOURS) // if credit hours greater than or equal to sophomore
                        {
                            // if beginning last name letter is between J and V
                            if ((string.Compare(firstLetterLastName, "J") >= 0) && (string.Compare(firstLetterLastName, "V") <= 0))
                            
                                registrationDateReturnLabel.Text = "November 9"; // date if letter is between letter J and V

                            else

                                registrationDateReturnLabel.Text = "November 10"; // date if letter is not between J and V
                        }
                        else // if freshman 
                        {
                            // if beginning last name letter is between J and V 
                            if ((string.Compare(firstLetterLastName, "J") >= 0) && (string.Compare(firstLetterLastName, "V") <= 0))

                                registrationDateReturnLabel.Text = "November 11"; // date if letter is between J and V

                            else

                                registrationDateReturnLabel.Text = "November 14"; // date if letter is not between J and V
                        }

                        switch (firstLetterLastName) // based on first letter in textbox will display correct time in the specified label 
                        {
                            case "A":
                            case "B":
                                registrationTimeReturnLabel.Text = "10:00 AM";
                                break;
                            case "C":
                            case "D":
                                registrationTimeReturnLabel.Text = "11:30 AM";
                                break;
                            case "E":
                            case "F":
                                registrationTimeReturnLabel.Text = "2:00 PM";
                                break;
                            case "G":
                            case "H":
                            case "I":
                                registrationTimeReturnLabel.Text = "4:00 PM";
                                break;
                            case "J":
                            case "K":
                            case "L":
                                registrationTimeReturnLabel.Text = "8:30 AM";
                                break;
                            case "M":
                            case "N":
                            case "O":
                                registrationTimeReturnLabel.Text = "10:00 AM";
                                break;
                            case "P":
                            case "Q":
                                registrationTimeReturnLabel.Text = "11:30 AM";
                                break;
                            case "R":
                            case "S":
                                registrationTimeReturnLabel.Text = "2:00 PM";
                                break;
                            case "T":
                            case "U":
                            case "V":
                                registrationTimeReturnLabel.Text = "4:00 PM";
                                break;
                            case "W":
                            case "X":
                            case "Y":
                            case "Z":
                                registrationTimeReturnLabel.Text = "8:30 AM";
                                break;

                        }
                    }                                        
                }
                // if credit hours is less than zero
                else

                    MessageBox.Show("LESS THAN ZERO CREDIT HOURS?");
            }
            // if credit hours textbox is blank
            else

                MessageBox.Show("NOT ACCEPTABLE CREDIT HOURS");


        }
    }
}
